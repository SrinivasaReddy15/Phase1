package program1;

public class M {
	private int a=10;
	long b=1200;
	protected float c=23.67F;
	public void publicfunc()
	{
		System.out.println("public method of M");
	}
	
	protected void protectedfunc()
	{
		System.out.println("protected method of M");
	}
	private void privatefunc()
	{
		System.out.println("private method of M");
	}
	
}
