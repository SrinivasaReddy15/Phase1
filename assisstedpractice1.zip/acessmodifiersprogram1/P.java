package program1;

public class P {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		M m=new M();
		N n=new N();
		System.out.println(m.b +" "+n.d);
	}

}
