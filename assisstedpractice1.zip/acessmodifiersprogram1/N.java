package program1;

public class N {
	public int d=10;
	double e=200;
	protected long f=2345;
	public void publicfunc()
	{
		System.out.println("public method of N");
	}
	
	protected void protectedfunc()
	{
		System.out.println("protected method of N");
	}
	private void privatefunc()
	{
		System.out.println("private method of N");
	}

}
