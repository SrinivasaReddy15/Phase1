package assisstedpractice1;

import java.util.*;

public class Collections {

	public static void main(String[] args) {
		//creating arraylist
		
		System.out.println("ArrayList");
		ArrayList<String> animals=new ArrayList<String>();   
		animals.add("Cat");//
		animals.add("Dog"); 
		animals.add("lion");
	      System.out.println(animals);  
		
		//creating vector
	      System.out.println();
	      System.out.println("Vector");
	      Vector<Integer> v = new Vector();
	      v.addElement(5); 
	      v.addElement(10); 
	      System.out.println(v);
		
		//creating linkedlist
	      System.out.println();
	      System.out.println("LinkedList");
	      LinkedList<String> names=new LinkedList<String>();  
	      names.add("sreenu");  
	      names.add("kalyan");  
	      names.add("charan"); 
	      Iterator<String> itr=names.iterator();  
	      while(itr.hasNext()){  
	       System.out.println(itr.next());  
	      }
	       //creating hashset
	       System.out.println();
	       System.out.println("HashSet");
	       HashSet<Integer> set=new HashSet<Integer>();  
	       set.add(1);  
	       set.add(2);  
	       set.add(3);
	       set.add(4);
	       System.out.println(set);
	       
	       //creating linkedhashset
	       System.out.println("\n");
	       System.out.println("LinkedHashSet");
	       LinkedHashSet<Integer> set1=new LinkedHashSet<Integer>();  
	       set1.add(1);  
	       set1.add(3);  
	       set1.add(2);
	       set1.add(4);	       
	       System.out.println(set1);
	      	} 
	      }  
	
