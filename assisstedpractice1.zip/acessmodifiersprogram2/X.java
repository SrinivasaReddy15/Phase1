package program2;

public class X {
	private int g=23;
	long h=123456;
	protected float i=34.67F;
	public char ch='r';

}
