package program2;
import program1.*;

public class Z {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		M m=new M();
		N n=new N();
		X x=new X();
		System.out.println(x.h+" "+x.ch);
		m.publicfunc();
		n.publicfunc();

	}

}
