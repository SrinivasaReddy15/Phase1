package assisstedpractice3;
import java.util.*;
public class Queuee {

	public static void main(String[] args) 
	{
	        		Queue<String> fruitsQueue = new LinkedList<>();
	        		fruitsQueue.add("Mango");
	        		fruitsQueue.add("Grapes");
	        		fruitsQueue.add("Orange");
	        		fruitsQueue.add("Sapota");
	        		fruitsQueue.add("Apple");
	System.out.println("Queue is : " + fruitsQueue);
	        		System.out.println("Head of Queue : " + fruitsQueue.peek());
	        		fruitsQueue.remove();
	        		System.out.println("After removing Head of Queue : " + fruitsQueue);
	        		System.out.println("Size of Queue : " + fruitsQueue.size());
	    	}
	}
