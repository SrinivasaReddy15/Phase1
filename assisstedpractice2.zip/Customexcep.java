package assisstedpractice2;

public class Customexcep extends Exception  {
	public Customexcep(String s) 
    { 
        super(s); 
    } 


	public static void main(String[] args) {
		// TODO Auto-generated method stub
        try
        { 
            throw new Customexcep("temp"); 
        } 
        catch (Customexcep ex) 
        { 
            System.out.println("Caught"); 
            System.out.println(ex.getMessage()); 
        } 

	}

}
