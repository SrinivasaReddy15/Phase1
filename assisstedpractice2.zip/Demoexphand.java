package assisstedpractice2;

public class Demoexphand {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			System.out.println("Starting of try block");
			// I'm throwing the custom exception using throw
			throw new Myexception("This is My error Message");
		}
		catch(Myexception exp){
			System.out.println("Catch Block") ;
			System.out.println(exp) ;
		}


	}

}
